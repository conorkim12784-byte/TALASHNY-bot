from pyrogram.enums import ChatMemberStatus
# Copyright (C) 2021 By Veez Music-Project

from pyrogram import Client
from pyrogram.errors import UserAlreadyParticipant, UserNotParticipant
from pyrogram.types import InlineKeyboardMarkup, Message
from pytgcalls.types import MediaStream, AudioQuality
from program.utils.inline import stream_markup
from driver.design.thumbnail import thumb
from driver.design.chatname import CHAT_TITLE
from driver.filters import command, other_filters
from driver.queues import QUEUE, add_to_queue
from driver.veez import call_py, user
from driver.utils import bash
from config import BOT_USERNAME, IMG_5
from youtubesearchpython import VideosSearch


def ytsearch(query: str):
    try:
        search = VideosSearch(query, limit=1).result()
        data = search["result"][0]
        songname = data["title"]
        url = data["link"]
        duration = data["duration"]
        thumbnail = f"https://i.ytimg.com/vi/{data['id']}/hqdefault.jpg"
        return [songname, url, duration, thumbnail]
    except Exception as e:
        print(e)
        return 0


async def ytdl(link: str):
    stdout, stderr = await bash(
        f'yt-dlp -g -f "best[height<=?720][width<=?1280]" {link}'
    )
    if stdout:
        return 1, stdout
    return 0, stderr


@Client.on_message(command(["mplay", "play"]) & other_filters)
async def play(c: Client, m: Message):
    await m.delete()
    replied = m.reply_to_message
    chat_id = m.chat.id
    user_id = m.from_user.id
    if m.sender_chat:
        return await m.reply_text(
            "you're an __Anonymous__ user !\n\n» revert back to your real user account to use this bot."
        )
    try:
        aing = await c.get_me()
    except Exception as e:
        return await m.reply_text(f"error:\n\n{e}")
    a = await c.get_chat_member(chat_id, aing.id)
    if a.status != ChatMemberStatus.ADMINISTRATOR:
        await m.reply_text(
            "💡 لاستخدامي ، يجب أن أكون ** مشرف ** مع ** الصلاحيات التالية **:\n\n» ❌ __حذف الرسائل__\n» ❌ __دعوة المستخدمين__\n» ❌ __ادارة المكالمات المرئية__\n\n** يتم تحديث البيانات ** تلقائيًا بعد أن تقوم بترقيتي **"
        )
        return
    if not getattr(a, "can_manage_video_chats", getattr(a, "can_manage_voice_chats", True)):
        await m.reply_text("ليس لدي صلاحية:" + "\n\n» ❌ __ادارة المكالمات المرئية__")
        return
    if not a.can_delete_messages:
        await m.reply_text("ليس لدي صلاحية:" + "\n\n» ❌ __حذف الرسائل__")
        return
    if not a.can_invite_users:
        await m.reply_text("ليس لدي صلاحية:" + "\n\n» ❌ __اضافة المستخدمين__")
        return
    try:
        ubot = (await user.get_me()).id
        b = await c.get_chat_member(chat_id, ubot)
        if b.status == "kicked":
            await c.unban_chat_member(chat_id, ubot)
            invitelink = await c.export_chat_invite_link(chat_id)
            if invitelink.startswith("https://t.me/+"):
                invitelink = invitelink.replace("https://t.me/+", "https://t.me/joinchat/")
            await user.join_chat(invitelink)
    except UserNotParticipant:
        try:
            invitelink = await c.export_chat_invite_link(chat_id)
            if invitelink.startswith("https://t.me/+"):
                invitelink = invitelink.replace("https://t.me/+", "https://t.me/joinchat/")
            await user.join_chat(invitelink)
        except UserAlreadyParticipant:
            pass
        except Exception as e:
            return await m.reply_text(f"❌ **فشل المساعد في الانضمام**\n\n**السبب**: `{e}`")

    if replied:
        if replied.audio or replied.voice:
            suhu = await replied.reply("📥 **جاري تنزيل الصوت...**")
            dl = await replied.download()
            link = replied.link
            try:
                if replied.audio:
                    songname = getattr(replied.audio, 'title', None) or getattr(replied.audio, 'file_name', 'Audio')
                    songname = songname[:70]
                    duration = replied.audio.duration
                elif replied.voice:
                    songname = "Voice Note"
                    duration = replied.voice.duration
            except Exception:
                songname = "Audio"
                duration = 0

            if chat_id in QUEUE:
                gcname = m.chat.title
                ctitle = await CHAT_TITLE(gcname)
                image = await thumb(IMG_5, songname, user_id, ctitle)
                pos = add_to_queue(chat_id, songname, dl, link, "Audio", 0)
                requester = f"[{m.from_user.first_name}](tg://user?id={user_id})"
                buttons = stream_markup(user_id)
                await suhu.delete()
                await m.reply_photo(
                    photo=image,
                    reply_markup=InlineKeyboardMarkup(buttons),
                    caption=f"💡 **تمت إضافة المقطع إلى قائمة الانتظار »** `{pos}`\n\n🏷 **الاسم:** [{songname}]({link})\n💭 **المجموعه:** `{chat_id}`\n⏱️ **المده:** `{duration}`\n🎧 **طلب بواسطة:** {requester}",
                )
            else:
                try:
                    gcname = m.chat.title
                    ctitle = await CHAT_TITLE(gcname)
                    image = await thumb(IMG_5, songname, user_id, ctitle)
                    await suhu.edit("🔄 **يتم التشغيل...**")
                    await call_py.play(
                        chat_id,
                        MediaStream(dl, audio_parameters=AudioQuality.HIGH),
                    )
                    add_to_queue(chat_id, songname, dl, link, "Audio", 0)
                    await suhu.delete()
                    buttons = stream_markup(user_id)
                    requester = f"[{m.from_user.first_name}](tg://user?id={user_id})"
                    await m.reply_photo(
                        photo=image,
                        reply_markup=InlineKeyboardMarkup(buttons),
                        caption=f"🏷 **الاسم:** [{songname}]({link})\n💭 **المجموعه:** `{chat_id}`\n⏱️ **المده:** `{duration}`\n🎧 **طلب بواسطة:** {requester}",
                    )
                except Exception as e:
                    await suhu.delete()
                    await m.reply_text(f"🚫 خطأ:\n\n» {e}")
        else:
            if len(m.command) < 2:
                await m.reply("» عليك الرد على ** ملف صوتي ** أو ** أكتب شي للبحث**")
            else:
                await _play_youtube(c, m, chat_id, user_id)
    else:
        if len(m.command) < 2:
            await m.reply("» عليك الرد على ** ملف صوتي ** أو ** أكتب شي للبحث**")
        else:
            await _play_youtube(c, m, chat_id, user_id)


async def _play_youtube(c: Client, m: Message, chat_id: int, user_id: int):
    suhu = await c.send_message(chat_id, "🔎 **جاري البحث...**")
    query = m.text.split(None, 1)[1]
    search = ytsearch(query)
    if search == 0:
        return await suhu.edit("❌ **لم يتم العثور على نتائج**")

    songname, url, duration, thumbnail = search
    gcname = m.chat.title
    ctitle = await CHAT_TITLE(gcname)
    image = await thumb(thumbnail, songname, user_id, ctitle)
    veez, ytlink = await ytdl(url)
    if veez == 0:
        return await suhu.edit(f"❌ تم اكتشاف مشاكل في yt-dlp\n\n» `{ytlink}`")

    requester = f"[{m.from_user.first_name}](tg://user?id={user_id})"
    buttons = stream_markup(user_id)
    if chat_id in QUEUE:
        pos = add_to_queue(chat_id, songname, ytlink, url, "Audio", 0)
        await suhu.delete()
        await m.reply_photo(
            photo=image,
            reply_markup=InlineKeyboardMarkup(buttons),
            caption=f"💡 **تمت إضافة المقطع إلى قائمة الانتظار »** `{pos}`\n\n🏷 **الاسم:** [{songname}]({url})\n💭 **المجموعه:** `{chat_id}`\n**⏱ المده:** `{duration}`\n🎧 **طلب بواسطة:** {requester}",
        )
    else:
        try:
            await suhu.edit("🔄 **يتم التشغيل...**")
            await call_py.play(
                chat_id,
                MediaStream(ytlink, audio_parameters=AudioQuality.HIGH),
            )
            add_to_queue(chat_id, songname, ytlink, url, "Audio", 0)
            await suhu.delete()
            await m.reply_photo(
                photo=image,
                reply_markup=InlineKeyboardMarkup(buttons),
                caption=f"💡 **تم تشغيل الموسيقى.**\n\n🏷 **الاسم:** [{songname}]({url})\n💭 **المجموعه:** `{chat_id}`\n**⏱ المده:** `{duration}`\n🎧 **طلب بواسطة:** {requester}",
            )
        except Exception as ep:
            await suhu.delete()
            await m.reply_text(f"🚫 خطأ: `{ep}`")
